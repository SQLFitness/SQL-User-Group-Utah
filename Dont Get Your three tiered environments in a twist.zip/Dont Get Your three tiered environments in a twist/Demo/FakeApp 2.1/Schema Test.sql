USE AdventureWorks_staging
GO

CREATE SCHEMA Test AUTHORIZATION dbo
 